## train

Step1. run yolo2coco.py.
```shell
parser.add_argument('--root_dir', default='./datasets', type=str,
                    help="root path of images and labels, include ./images and ./labels and classes.txt")
parser.add_argument('--save_path', type=str, default='./val.json',
                    help="if not split the dataset, give a path to a json file")
parser.add_argument('--random_split', action='store_true', help="random split the dataset, default ratio is 8:1:1")
```

Step2. rewrite coco_classes.py.

```shell
COCO_CLASSES = (
    "0",
    "1",
)
```

Step3. rewrite yolox_base.py.

```shell
self.num_classes = 2

self.input_size = (512, 640)  # (height, width)

self.train_ann = "train.json"
self.train_imgs = "train_images"
self.val_ann = "val.json"
self.val_imgs = "val_images"

# and other cfg

name=self.train_imgs

name=self.val_imgs

```

Step4. run train.py.

```shell
python tools/train.py -n yolox-s -d 8 -b 64 --fp16 -o [--cache]
                         yolox-m
                         yolox-l
                         yolox-x
```


## eval

Step1. run eval.py.

```shell
python tools/eval.py -n  yolox-s -c yolox_s.pth -b 1 -d 1 --conf 0.2 --nms 0.05 --fp16 --fuse
                         yolox-m
                         yolox-l
                         yolox-x
```


## demo


Step1. rewrite demo.py.

```shell
img_info["file_name"] = img

with open(img_info["file_name"].replace("jpg", "txt").replace("val_images", "_val_labels"), "w") as f:
    pass

with open(img_info["file_name"].replace("jpg", "txt").replace("val_images", "_val_labels"), "w") as f:
    for i in range(len(bboxes)):
        box = bboxes[i]
        cls_id = int(cls[i])
        score = scores[i]
        if score < cls_conf:
            continue
        x0 = int(box[0])
        y0 = int(box[1])
        x1 = int(box[2])
        y1 = int(box[3])
        text = '{} {} {} {} {} {}'.format(cls_id, score, float(x0 + x1) / 2 / 640, float(y0 + y1) / 2 / 512,
                                          float(x1 - x0) / 640, float(y1 - y0) / 512)
        f.write(text + "\n")
```

Step2. run demo.py.

```shell
python tools/demo.py image -n  yolox-s -c YOLOX_outputs/yolox_s/best_ckpt.pth --path datasets/COCO/val_images --conf 0.2 --nms 0.4  --tsize 640 --save_result --device gpu
```